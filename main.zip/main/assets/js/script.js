document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('churn-prediction-container');
    container.innerHTML = `
        <h1>Customer Churn Prediction</h1>
        <p>Upload your CSV file and filter predictions by churn probability range:</p>
        <form id="upload-form" enctype="multipart/form-data">
            <label for="csv-file">Upload CSV</label>
            <input type="file" id="csv-file" name="file" accept=".csv" required>
            <label for="min-churn">Min Churn Probability (%)</label>
            <input type="number" id="min-churn" name="min-churn" min="0" max="100" value="80" required>
            <label for="max-churn">Max Churn Probability (%)</label>
            <input type="number" id="max-churn" name="max-churn" min="0" max="100" value="100" required>
            <button type="submit">Predict</button>
        </form>
        <div id="result" style="display:none;">
            <h2>Prediction Results</h2>
            <table id="results-table">
                <thead>
                    <tr>
                        <th>Customer ID</th>
                        <th data-column="CLTV">CLTV</th>
                        <th data-column="ChargesPerMonth">Charges Per Month</th>
                        <th data-column="ChurnProbabilities">Churn Probability</th>
                        <th>Risk Level</th>
                    </tr>
                </thead>
                <tbody id="results-body"></tbody>
            </table>
            <div id="pagination"></div>
        </div>
        <div id="loading-spinner" style="display:none;">
            <div class="spinner"></div>
        </div>
    `;

    // JavaScript Logic for Sorting, Pagination, and Predictions
    let predictions = [];
    let currentPage = 1;
    const resultsPerPage = 30;
    let currentSortColumn = null;
    let sortDirection = 'asc';

    document.getElementById('upload-form').addEventListener('submit', async function(event) {
        event.preventDefault();
        const fileInput = document.getElementById('csv-file');
        const minChurn = parseFloat(document.getElementById('min-churn').value) / 100;
        const maxChurn = parseFloat(document.getElementById('max-churn').value) / 100;

        const formData = new FormData();
        formData.append('file', fileInput.files[0]);

        document.getElementById('loading-spinner').style.display = 'block';
        document.getElementById('result').style.display = 'none';

        try {
            const response = await fetch('http://127.0.0.1:8000/predict-churn', {
                method: 'POST',
                body: formData,
            });

            if (response.ok) {
                const result = await response.json();
                predictions = result.predictions.filter(prediction =>
                    prediction.ChurnProbabilities >= minChurn &&
                    prediction.ChurnProbabilities <= maxChurn
                );

                displayResults();
            } else {
                alert('Error: ' + (await response.text()));
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Could not connect to the server.');
        } finally {
            document.getElementById('loading-spinner').style.display = 'none';
        }
    });

    function displayResults() {
        const resultsBody = document.getElementById('results-body');
        resultsBody.innerHTML = '';

        const startIndex = (currentPage - 1) * resultsPerPage;
        const endIndex = Math.min(startIndex + resultsPerPage, predictions.length);

        for (let i = startIndex; i < endIndex; i++) {
            const prediction = predictions[i];
            const riskLevel = prediction.ChurnProbabilities > 0.8 ? 'High' :
                              prediction.ChurnProbabilities > 0.5 ? 'Medium' : 'Low';
            const row = `
                <tr>
                    <td>${prediction.CustomerID}</td>
                    <td>${prediction.CLTV}</td>
                    <td>${prediction.ChargesPerMonth}</td>
                    <td>${(prediction.ChurnProbabilities * 100).toFixed(2)}%</td>
                    <td>${riskLevel}</td>
                </tr>
            `;
            resultsBody.innerHTML += row;
        }

        updatePagination();
        document.getElementById('result').style.display = 'block';
    }

    function updatePagination() {
        const pagination = document.getElementById('pagination');
        pagination.innerHTML = '';

        const totalPages = Math.ceil(predictions.length / resultsPerPage);

        const prevButton = document.createElement('button');
        prevButton.textContent = 'Previous';
        prevButton.disabled = currentPage === 1;
        prevButton.addEventListener('click', () => {
            currentPage--;
            displayResults();
        });
        pagination.appendChild(prevButton);

        const pageCounter = document.createElement('span');
        pageCounter.textContent = ` Page ${currentPage} of ${totalPages} `;
        pagination.appendChild(pageCounter);

        const nextButton = document.createElement('button');
        nextButton.textContent = 'Next';
        nextButton.disabled = currentPage === totalPages;
        nextButton.addEventListener('click', () => {
            currentPage++;
            displayResults();
        });
        pagination.appendChild(nextButton);
    }

    function sortResults(column) {
        if (currentSortColumn === column) {
            sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
        } else {
            currentSortColumn = column;
            sortDirection = 'asc';
        }

        predictions.sort((a, b) => {
            const valA = a[column];
            const valB = b[column];

            if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
            if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
            return 0;
        });

        currentPage = 1;
        displayResults();
    }

    document.addEventListener('DOMContentLoaded', () => {
        const headers = document.querySelectorAll('#results-table th[data-column]');
        headers.forEach(header => {
            header.addEventListener('click', () => {
                const column = header.getAttribute('data-column');
                if (column) sortResults(column);
            });
        });
    });
});
